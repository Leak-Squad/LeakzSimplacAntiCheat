--] Leak by Taco --- Leak Squad....
print("[/Simplac/] Loaded!")

Simplac = Simplac or {}
Simplac.servertick = 1 / engine.TickInterval()
Simplac.tickinterval = engine.TickInterval()
Simplac.violations = {}
Simplac.beingpunished ={}
Simplac.joinnick = Simplac.joinnick or {}

include("settings_simplac.lua")

Simplac.Log = {}

function Simplac.Log.Player(formatted_time_date, joinnick, ident, plyent, violation)


	print("[/Simplac/] (" .. ident .. ") " .. joinnick .. " violated something.")

	local folders = "simplac/cheaters/" .. ident
	local filename = folders .. "/" .. formatted_time_date .. ".txt"


	file.CreateDir(folders)

	if(not file.Read(filename, "DATA")) then
		file.Write(filename, "Violation: " .. violation .. "\n")
	else
		file.Append(filename, "Violation: " .. violation .. "\n")
	end

end

function Simplac.Log.Handler(...)

	local args = {...}

	local customlog = hook.Call("Simplac.Log.Handler", nil, unpack(args))

	if(customlog) then
		return
	end
	

	local formatted_time_date = os.date("%d_%m_%Y (%H_%M_%S)", os.time())

	local stype = args[1]

	if(stype == "ply_violation") then
		table.remove(args,1)
		Simplac.Log.Player(formatted_time_date, unpack(args))
	end

end

function Simplac.PlayerInitialSpawn(ply)

	if(ply:IsBot()) then return end

	local ident = ply:SteamID64()

	if(Simplac.beingpunished[ident]) then return end

	Simplac.joinnick[ident] = ply:Nick()
	Simplac.violations[ident] = {}
end

hook.Add("PlayerInitialSpawn", "Simplac.PlayerInitialSpawn", Simplac.PlayerInitialSpawn)


function Simplac.ExternalPunishment(ply, ident, violations)

	local bantime = Simplac.settings.bantime
	
	if(not bantime) then
		bantime = 0
	end

	local reason = Simplac.settings.banreason

	if(not reason) then
		reason = "Cheating"
	end

	if(reason == "badidea") then
		reason = "bad idea host. | " .. table.concat(violations, ";")
	end

	local sid32 = util.SteamIDFrom64(ident)
	local nick = Simplac.joinnick[ident]

	if(GB_InsertBan) then
		print("Punishing using global bans..")
		GB_InsertBan(sid32, nick, bantime, "SimpLAC", "STEAM_0:0:10134848",  reason)
		return
	end

 	if(ULib and ULib.bans) then
 		print("Punishing using ulx..")
 		if(IsValid(ply)) then
			RunConsoleCommand("ulx", "ban", ply:Nick(), bantime, reason)
		else
			RunConsoleCommand("ulx", "banid", sid32, bantime, reason)
		end

		return
 	end

 	if(serverguard) then
 		print("Punishing using serverguard..")
 		serverguard:BanPlayer(nil, sid32, bantime, reason, nil, nil, "SimpLAC")
 		return
 	end

	ply:Ban(bantime, reason)
end

function Simplac.Punish( ident, violations )

	local plyent = nil

	for k,ply in pairs(player.GetAll()) do
		if(ply:SteamID64() == ident) then
			plyent = ply
		end
	end

	for k,v in pairs(player.GetAll()) do
		if(plyent and IsValid(plyent)) then
			v:ChatPrint( ident .. " == " .. plyent:Nick() .. " is a cheater!")
		else
			v:ChatPrint( ident .. " is a cheater!")
		end
	end

	if(not Simplac.settings.testmode) then
		Simplac.ExternalPunishment(plyent, ident, violations)
	end

	timer.Simple(3, function()
		if(plyent and IsValid(plyent)) then
			plyent:Kick("get out: " .. table.concat(violations, ";"))
		end
	end)


	Simplac.beingpunished[ident] = false
	Simplac.violations[ident] = nil
end


function Simplac.PlayerViolation( ply, violation )

	local ident = ply:SteamID64()


	Simplac.violations[ident] = Simplac.violations[ident] or {}
	--if(table.HasValue(Simplac.violations, violation)) then return end -- It's already in there

	local shouldignore = hook.Call( "Simplac.PlayerViolation", nil, ply, ident, violation )

	if shouldignore then
		return
	end

	Simplac.Log.Handler("ply_violation", Simplac.joinnick[ident], ident, ply, violation)
	Simplac.beingpunished[ident] = true

	table.insert(Simplac.violations[ident], violation)

	timer.Create("Simplac_topunish_" .. ident, 10, 1, function()
		Simplac.Punish(ident, Simplac.violations[ident])
	end)

end


function Simplac.MouseCheck(ply, cmd)


	if(ply.simplac_beingignored) then return end

	if(ply.mouse_isrip) then
		if(not ply.mouse_infangs) then
			ply.mouse_infangs = true
			Simplac.PlayerViolation(ply, "MC" .. tostring(ply.mouse_isrip))
			return
		end
		
		return
	end
	
	ply.mouse_violatecount = ply.mouse_violatecount or 0
	
	if(math.abs(cmd:GetMouseX()) > 7680) then
		ply.mouse_isrip = 1
		return
	end
	
	if(math.abs(cmd:GetMouseY()) > 4320) then
		ply.mouse_isrip = 2
		return
	end 
	
	if(ply.mouse_lastx) then
		--if(ply.mouse_lastx == cmd:GetMouseX() and ply.mouse_lasty == cmd:GetMouseY() and cmd:GetMouseX() != 0 and cmd:GetMouseY() != 0) then
		--	ply.mouse_isrip = 4
		--	return
		--end
	end

	if(not ply.mouse_lastang) then ply.mouse_lastang = cmd:GetViewAngles() return end
		
	if(ply.mouse_lastang != cmd:GetViewAngles()) then
			
		if(cmd:GetMouseX() == 0 and cmd:GetMouseY() == 0) then 
			ply.mouse_violatecount = ply.mouse_violatecount + 1 
		else
			if(ply.mouse_violatecount>0) then
				ply.mouse_violatecount = ply.mouse_violatecount - 1
			end
		end
			
		timer.Create("mouse_violatecount_cd_" .. ply:SteamID64(), 1, 1, function() -- auto cooldown
			if(not ply or not IsValid(ply)) then return end
		--	print("hi")
			ply.mouse_violatecount = 0
		end)
			
	end	

	if(ply.mouse_violatecount != 0) then
		--	print(ply.mouse_violatecount)
	end
	
	
	if(ply.mouse_violatecount > 20) then
		ply.mouse_violatecount = 0
		ply.mouse_isrip = 3
		return
	end
	
	ply.mouse_lastx = cmd:GetMouseX()
	ply.mouse_lasty = cmd:GetMouseY()
	
	ply.mouse_lastang = cmd:GetViewAngles()

end

function Simplac.SeedCheck(ply, cmd)

	if(ply.simplac_beingignored) then return end

	if(ply.seed_isrip) then
		if(not ply.seed_infangs) then
			ply.seed_infangs = true
			Simplac.PlayerViolation(ply, "SC" .. tostring(ply.seed_isrip) .. "=" .. tostring(ply.seed_violatecounta) .. ";" .. tostring(ply.seed_violatecountb))
			return
		end
		return
	end

	ply.seed_lastcmdnum = ply.seed_lastcmdnum or -1
	ply.seed_violatecounta = ply.seed_violatecounta or 0
	ply.seed_violatecountb = ply.seed_violatecountb or 0

	local lastnum = ply.seed_lastcmdnum
	local curnum = cmd:CommandNumber()

	if(curnum == lastnum) then
		ply.seed_violatecounta = ply.seed_violatecounta + 1

		--ply:ChatPrint(tostring(ply.seed_violatecounta))

		timer.Simple(3, function()
			if(not ply or not IsValid(ply)) then return end
			ply.seed_violatecounta = 0
		end)
	end

	if(curnum > lastnum + 50) then
		ply.seed_violatecountb = ply.seed_violatecountb + 1

		timer.Simple(3, function()
			if(not ply or not IsValid(ply)) then return end
			ply.seed_violatecountb = 0
		end)
	end

	if(ply.seed_violatecounta > Simplac.servertick* 0.75) then
		ply.seed_isrip = 1
	end

	if(ply.seed_violatecountb > Simplac.servertick* 0.50) then
		ply.seed_isrip = 2
	end

	ply.seed_lastcmdnum = curnum
end

/*
ocmdnum = ocmdnum or debug.getregistry()["CUserCmd"]["CommandNumber"]

debug.getregistry()["CUserCmd"]["CommandNumber"] = function(self)
	
	if(is_fake) then
		return 128
	end

	return ocmdnum(self)
end

concommand.Add("+fakecmdnum", function(p)
	is_fake = true
end)

concommand.Add("-fakecmdnum", function(p)
	is_fake = false
end)*/

function Simplac.AutofireCheck(ply, cmd)

	if(ply.simplac_beingignored) then return end

	if(ply.autofire_isrip) then
		if(not ply.autofire_infangs) then
			ply.autofire_infangs = true
			Simplac.PlayerViolation(ply, "AF" .. tostring(ply.autofire_violations) .. ";" .. Simplac.tickinterval * 20)
			return
		end
		return
	end

	local is_firing = bit.band(cmd:GetButtons(), IN_ATTACK)


	ply.autofire_violations = ply.autofire_violations or 0


	if( is_firing != ply.autofire_didfire) then

		ply.autofire_violations = ply.autofire_violations + 1

		if(ply.autofire_violations>10) then
			--ply:ChatPrint("get stirbt: " .. tostring(ply.autofire_violations))
			--print("get stirbt")
			ply.autofire_isrip = 1
		end

		timer.Simple(Simplac.tickinterval*20, function()
			if(not ply or not IsValid(ply)) then return end
			ply.autofire_violations = 0
		end)
	end

	ply.autofire_didfire = is_firing
end

function Simplac.Aimbot_NCheck(ply, cmd)

	if(ply.simplac_beingignored) then return end

	if(ply.aimbot_isrip) then
		if(not ply.aimbot_infangs) then
			ply.aimbot_infangs = true
			Simplac.PlayerViolation(ply, "AN" .. tostring(ply.aimbot_isrip_y) .. ";" .. Simplac.tickinterval)
			return
		end
		return
	end

	if(not ply.aimbot_lastangs) then
		ply.aimbot_lastangs = {}
	end


	local curang = cmd:GetViewAngles()

	table.insert(ply.aimbot_lastangs, curang)

	local lastdiff = Angle(0,0,0)

	local matchingdiffs = 0

	for k, ang in pairs(ply.aimbot_lastangs) do

		local diff = curang - ang
		if(diff.x == 0 or diff.y == 0) then continue end

		if(diff.x == lastdiff.x and diff.y == lastdiff.y) then
			matchingdiffs = matchingdiffs + 1
		end
	end

	if(matchingdiffs>=2) then
		ply.aimbot_isrip = true
		ply.aimbot_isrip_y = 1
		return
	end

	for k, ang in pairs(ply.aimbot_lastangs) do
		local diff = curang - ang

		local maxm = 45
		if(diff.x > maxm or diff.y > maxm) then
			ply.aimbot_issnapping = true
			--ply:ChatPrint("snapped")
			timer.Simple(0.5, function()
				if(not ply or not IsValid(ply)) then return end
				ply.aimbot_issnapping = false
			end)
		end
	end

	if(table.Count(ply.aimbot_lastangs)>20) then
		while(table.Count(ply.aimbot_lastangs)>20) do
			table.remove(ply.aimbot_lastangs, 1)
		end
	end
end

function Simplac.BhopCheck(ply, cmd)

	if(ply.simplac_beingignored) then return end

	ply.bhop_violations = ply.bhop_violations or 0

	if(ply.bhop_isrip) then
		if(not ply.bhop_infangs) then
			ply.bhop_infangs = true
			Simplac.PlayerViolation(ply, "BH" .. "=" .. Simplac.tickinterval)
			return
		end
		return
	end

	if(!cmd:KeyDown(IN_JUMP) and ply:IsOnGround() and ply.bhop_time) then
		ply.bhop_time = 0
		ply.bhop_violations = 0
	end

	if(cmd:KeyDown(IN_JUMP) and not ply.bhop_didjump) then
		if(ply:IsOnGround()) then
			local current = CurTime()

			if(ply.bhop_time and current > ply.bhop_time) then
				ply.bhop_violations = ply.bhop_violations + 1
				--ply:ChatPrint(tostring(ply.bhop_violations))
				if(ply.bhop_violations>8) then
					ply.bhop_isrip = true
				end
			else
				ply.bhop_time = CurTime() + 0.5
			end
		else
			ply.bhop_time = 0
		end
	end

	ply.bhop_didjump = cmd:KeyDown(IN_JUMP)

end

timer.Create("Simplac.Bhop_DecreaseCount", 4, 0, function()
	for k,v in pairs(player.GetAll()) do
		if(v.bhop_violations and v.bhop_violations != 0) then
			v.bhop_violations = v.bhop_violations - 1
		end
	end
end)

function Simplac.StartCommand(ply, cmd)
		

	if (not IsValid(ply)) then return end
	if(ply:IsBot()) then return end

	Simplac.MouseCheck(ply, cmd)
	Simplac.SeedCheck(ply, cmd)
	Simplac.AutofireCheck(ply, cmd)
	Simplac.BhopCheck(ply, cmd)
	Simplac.Aimbot_NCheck(ply, cmd)


end


hook.Add("StartCommand", "Simplac.StartCommand", Simplac.StartCommand)

hook.Add("EntityTakeDamage", "Simplac.EntityTakeDamage", function(target, dmg)

	local atk = dmg:GetAttacker()

	if(not IsValid(atk) or not IsValid(target)) then return end
	if(not atk:IsPlayer()) then return end 
	if(not target:IsNPC() and not target:IsPlayer()) then return end
	if(atk:IsBot()) then return end
	
	if(atk.aimbot_issnapping) then
		atk.aimbot_isrip = true
		atk.aimbot_isrip_y = 2
	end

end)