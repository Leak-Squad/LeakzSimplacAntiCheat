
Simplac = Simplac or {}
Simplac.settings = {}
Simplac.settings.bantime = 0 -- Permanent
Simplac.settings.banreason = "Cheating"

Simplac.settings.testmode = false -- test mode (disable bans)